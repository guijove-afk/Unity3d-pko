using UnityEngine;
using UnityEngine.UI;
using Mirror;

public class HPBar : MonoBehaviour
{
    public Slider slider;
    private Health target;

    void Update()
    {
        if (target != null && slider != null)
        {
            slider.value = target.hp;
        }
    }

    public void SetTarget(Health newTarget)
    {
        target = newTarget;
    }
}