using UnityEngine;
using UnityEngine.UI;

public class HPBarWorld : MonoBehaviour
{
    public Slider slider;
    public Transform target;
    public Vector3 offset = new Vector3(0, 2, 0);

    void Update()
    {
        if (target == null) return;

        transform.position = target.position + offset;

        if (Camera.main != null)
            transform.forward = Camera.main.transform.forward;
    }

    public void SetHP(int hp)
    {
        slider.value = hp;
    }
}