using Mirror;
using UnityEngine;

public class Health : NetworkBehaviour
{
    [SyncVar(hook = nameof(OnHpChanged))]
    public int hp = 100;

    public int maxHp = 100;

    public GameObject damagePopupPrefab;

    public override void OnStartServer()
    {
        hp = maxHp;
    }

    // =========================
    // DAMAGE (SERVER ONLY)
    // =========================
    [Server]
    public void TakeDamage(int damage)
    {
        if (hp <= 0)
            return;

        hp -= damage;

        if (hp < 0)
            hp = 0;

        RpcShowDamage(damage);

        if (hp == 0)
        {
            Die();
        }
    }

    // =========================
    // DEATH (SERVER ONLY)
    // =========================
    [Server]
    void Die()
    {
        NetworkServer.Destroy(gameObject);
    }

    // =========================
    // SYNC HP (UI / CLIENT)
    // =========================
    void OnHpChanged(int oldHp, int newHp)
    {
        // aqui depois você conecta sua HP bar se quiser
        // Debug.Log($"HP: {oldHp} -> {newHp}");
    }

    // =========================
    // DAMAGE POPUP (CLIENT)
    // =========================
    [ClientRpc]
    void RpcShowDamage(int damage)
    {
        if (!isClient)
            return;

        if (DamagePopupManager.Instance == null)
            return;

        DamagePopupManager.Instance.ShowDamage(damage, transform);
    }
}