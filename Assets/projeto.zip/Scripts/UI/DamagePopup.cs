using TMPro;
using UnityEngine;

public class DamagePopup : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 30f;
    [SerializeField] private float lifetime = 1.2f;

    private TextMeshProUGUI text;
    private RectTransform rect;
    private Transform target;

    private float timer;

    void Awake()
    {
        text = GetComponentInChildren<TextMeshProUGUI>();
        rect = GetComponent<RectTransform>();
    }

    public void Setup(int damage, Transform followTarget)
    {
        text.text = "-" + damage;
        target = followTarget;
    }

    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }

        timer += Time.deltaTime;

        Vector3 worldPos = target.position + Vector3.up * 2f;
        Vector3 screenPos = Camera.main.WorldToScreenPoint(worldPos);

        rect.position = screenPos;

        rect.anchoredPosition += Vector2.up * moveSpeed * Time.deltaTime;

        Color c = text.color;
        c.a = Mathf.Lerp(1, 0, timer / lifetime);
        text.color = c;

        if (timer >= lifetime)
            Destroy(gameObject);
    }
}