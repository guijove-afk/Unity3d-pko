using UnityEngine;

public class DamagePopupManager : MonoBehaviour
{
    public static DamagePopupManager Instance;

    public GameObject popupPrefab;
    public Canvas worldCanvas;

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    public void ShowDamage(int damage, Transform target)
    {
        if (popupPrefab == null || worldCanvas == null)
        {
            Debug.LogError("PopupPrefab ou Canvas não configurado!");
            return;
        }

        GameObject popup = Instantiate(popupPrefab, worldCanvas.transform);

        DamagePopup dp = popup.GetComponent<DamagePopup>();
        dp.Setup(damage, target);
    }
}